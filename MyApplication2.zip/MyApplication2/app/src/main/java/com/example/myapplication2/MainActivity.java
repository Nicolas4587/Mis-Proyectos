package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView Tvresultado;

    EditText etnum1;
    EditText etnum2;

    Button btsumar , btresta, btmultiplicar , btdividir;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Tvresultado = findViewById(R.id.tv_resultado);
        etnum1 = findViewById(R.id.et_num1);
        etnum2 = findViewById(R.id.et_num2);
        btsumar = findViewById(R.id.btn_sumar);
        btresta = findViewById(R.id.btn_restar);
        btmultiplicar = findViewById(R.id.btn_multiplicar);
        btdividir = findViewById(R.id.btn_dividir);


    }
}